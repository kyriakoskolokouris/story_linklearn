"use strict";

var kitty = {
    name: "Squiggy",
    color: "orange",
    age: 5,
    chipId: "ZA123456",
};
